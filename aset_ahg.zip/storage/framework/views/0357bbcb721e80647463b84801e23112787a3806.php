<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>LAPORAN PENERIMAAN PDF</title>

    <style>
        table td {
            /* font-family: Arial, Helvetica, sans-serif; */
            font-size: 14px;
        }
        table.data td,
        table.data th {
            border: 1px solid #ccc;
            padding: 5px;
        }
        table.data {
            border-collapse: collapse;
        }
        .text-center {
            text-align: center;
        }
        .text-right {
            text-align: right;
        }
    </style>
</head>
<body>
    <table width="100%">
        <tr>
            <td rowspan="4" width="60%">
                <img src="<?php echo e(public_path($setting->path_logo)); ?>" alt="<?php echo e($setting->path_logo); ?>" width="120">
                <br>
                <?php echo e($setting->alamat); ?>

                <br>
            </td>
            <td width="40%">Tanggal Cetak : <?php echo e(tanggal_indonesia(date('Y-m-d'))); ?></td>
        </tr>
    </table>
        <h1 class="text-center">Laporan Penerimaan Sparepart Kendaraan <?php echo e($member->kode_kabin); ?></h1>
        <h2 class="text-center">Periode <?php echo e(tanggal_indonesia($tanggal_awal, false)); ?> - <?php echo e(tanggal_indonesia($tanggal_akhir, false)); ?></h2>

    <?php $__currentLoopData = $perencanaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <table width="100%" style="margin-top: 15px">
        <tr>
            <td width="10%">Kode Penerimaan : <?php echo e($item->nomor_terima ?? ''); ?></td>
        </tr>  
        <tr>
            <td width="70%">Tanggal Permintaan : <?php echo e(tanggal_indonesia($item->tanggal_rencana, false)); ?></td>
        </tr>  
    </table>
    <table class="data" width="100%" style="margin-top: 15px">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Barang</th>
                <th>Jumlah</th>
                <th>Subtotal</th>
            </tr>
        </thead>
        <?php
            $no = 1;
            $detail = DB::table('penerimaan_detail')
                        ->leftjoin('barang', 'barang.id_barang', '=', 'penerimaan_detail.id_barang')
                        ->where('id_penerimaan', $item->id_penerimaan)
                        ->where('deleted_at', NULL)->get();
            $sum = $detail->sum('subtotal_terima'); 
        ?>
        <tbody>
            <?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($item->nama_barang); ?></td>
                    <td class="text-right"><?php echo e($item->jumlah_terima); ?></td>
                    <td class="text-right"><?php echo e("Rp. " .  format_uang($item->subtotal_terima)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" class="text-right"><b>Total biaya</b></td>
                <td class="text-right"><b><?php echo e("Rp. " .  format_uang($sum)); ?></b></td>
            </tr>
        </tfoot>
    </table>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
    <h2 class="text-right">Total Biaya : <?php echo e('Rp. ' . format_uang($total)); ?></h2>
</body>
</html><?php /**PATH F:\aset_ahg\resources\views/laporan_penerimaan/laporan.blade.php ENDPATH**/ ?>