<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Nota PDF</title>

    <style>
        table td {
            /* font-family: Arial, Helvetica, sans-serif; */
            font-size: 14px;
        }
        table.data td,
        th {
            border: 1px solid rgb(0, 0, 0);
            padding: 10px;
        }
        table.data {
            border-collapse: collapse;
        }
        .text-center {
            text-align: center;
        }
        .text-right {
            text-align: right;
        }
    </style>
</head>
<body>
<div class="border">
        <table class="table header" width="100%">
            <thead>
                <tr>
                    <th>PT. ARMADA HADA GRAHA</th>
                    <th>KENDARAAN & PERALATAN</th>
                    <th><?php echo e($permintaan->kode_permintaan); ?></th>
                </tr>
            </thead>
        </table>
    </div>
    <h1 class="text-center">FORM PERMINTAAN SERVICE</h1>

    <table width="60%">
    <tr>
            <td>Kode Permintaan</td>
            <td>: <?php echo e($permintaan->kode_permintaan); ?></td>
        </tr>
        <tr>
            <td>Tanggal Permohonan</td>
            <td>: <?php echo e(tanggal_indonesia($permintaan->tanggal)); ?></td>
        </tr>
        <tr>
            <td>Nama Pemohon</td>
            <td>: <?php echo e($permintaan->user); ?></td>
        </tr>
        <tr>
            <td>Unit</td>
            <td>: <?php echo e($permintaan->lokasi->nama_lokasi ?? ''); ?></td>
        </tr>
    </table>
    <hr>
    <table width="52%">
        <tr>
            <td>Kategori Alat</td>
            <td>: <?php echo e($permintaan->member->kategori->nama_kategori); ?></td>
        </tr>
        <tr>
            <td>No. Lambung</td>
            <td>: <?php echo e($permintaan->member->kode_kabin ?? ''); ?></td>
        </tr>
        <tr>
            <td>Nopol/Identitas</td>
            <td>: <?php echo e($permintaan->member->nopol ?? ''); ?></td>
        </tr>
        <tr>
            <td>KM</td>
            <td>: <?php echo e($permintaan->km ?? ''); ?></td>
        </tr>
    </table>
    <hr>
    <table width="50%">
        <tr>
            <td>Keluhan : </td>
        </tr>
    </table>
    <table width="50%" style="margin-left: 190px; margin-top:-50px">
    <?php $__currentLoopData = $trimed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($loop->iteration); ?>.</td>
            <td><?php echo e($item); ?></td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <hr>
    <br>
    <table width="100%">
            <tr>
                <td class="text-center">
                    Admin
                    <br>
                    <br>
                    <br>
                    <br>
                    <?php echo e(auth()->user()->name); ?>

                </td>
                <td class="text-center">
                    Mekanik
                    <br>
                    <br>
                    <br>
                    <br>
                    <?php echo e($permintaan->mekanik->nama_petugas); ?>

                </td>
                <td class="text-center">
                    Menyetujui
                    <br>
                    <br>
                    <br>
                    <br>             
                Ian Arisaputra Sutono
                </td>
                <td class="text-center">
                    Mengetahui
                    <br>
                    <br>
                    <br>
                    <br>
                    Subagyo
                </td>
            </tr>
    </table>
</body>
</html><?php /**PATH F:\aset_ahg\resources\views/permintaan/form_service.blade.php ENDPATH**/ ?>