<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>LAPORAN MOBILISASI PDF</title>

    <style>
        table td {
            /* font-family: Arial, Helvetica, sans-serif; */
            font-size: 14px;
        }
        table.data td,
        table.data th {
            border: 1px solid #ccc;
            padding: 5px;
        }
        table.data {
            border-collapse: collapse;
        }
        .text-center {
            text-align: center;
        }
        .text-right {
            text-align: right;
        }
    </style>
</head>
<body>
    <table width="100%">
        <tr>
            <td rowspan="4" width="60%">
                <img src="<?php echo e(public_path($setting->path_logo)); ?>" alt="<?php echo e($setting->path_logo); ?>" width="120">
                <br>
                <?php echo e($setting->alamat); ?>

                <br>
            </td>
            <td width="40%">Tanggal Cetak : <?php echo e(tanggal_indonesia(date('Y-m-d'))); ?></td>
        </tr>
    </table>
        <?php if($lokasi == 'Semua Data'): ?>
            <h3 class="text-center">Laporan Mobilisasi Aset Seluruh Permintaan</h3>
        <?php else: ?>
            <h3 class="text-center">Laporan Mobilisasi Aset Pada <?php echo e($lokasi->nama_lokasi); ?></h3>
        <?php endif; ?>
        <h2 class="text-center">Periode <?php echo e(tanggal_indonesia($tanggal_awal, false)); ?> - <?php echo e(tanggal_indonesia($tanggal_akhir, false)); ?></h2>

    <?php if($lokasi == 'Semua Data' ): ?>
    <table class="data" width="100%" style="margin-top: 15px">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode Mobilisasi</th>
                <th>kode Aset</th>
                <th>Identitas Aset</th>
                <th>User</th>
                <th>Tanggal Mobilisasi</th>
                <th>Tanggal Kembali</th>
                <th>Lokasi</th>
            </tr>
        </thead>
        <?php
            $no = 1;
        ?>
        <tbody>
            <?php $__currentLoopData = $permintaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($item->kode_mobilisasi); ?></td>
                    <td><?php echo e($item->kode_kabin); ?></td>
                    <td><?php echo e($item->nopol); ?></td>
                    <td><?php echo e($item->user); ?></td>
                    <td><?php echo e(tanggal_indonesia($item->tanggal_awal, false)); ?></td>
                    <td><?php echo e($item->tanggal_kembali ? tanggal_indonesia($item->tanggal_kembali, false) : ''); ?></td>
                    <td><?php echo e($item->nama_lokasi); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php else: ?>
    <table class="data" width="100%" style="margin-top: 15px">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode Mobilisasi</th>
                <th>kode Aset</th>
                <th>Identitas Aset</th>
                <th>User</th>
                <th>Tanggal Mobilisasi</th>
                <th>Tanggal Kembali</th>
            </tr>
        </thead>
        <?php
            $no = 1;
        ?>
        <tbody>
            <?php $__currentLoopData = $permintaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($item->kode_mobilisasi); ?></td>
                    <td><?php echo e($item->kode_kabin); ?></td>
                    <td><?php echo e($item->nopol); ?></td>
                    <td><?php echo e($item->user); ?></td>
                    <td><?php echo e(tanggal_indonesia($item->tanggal_awal, false)); ?></td>
                    <td><?php echo e($item->tanggal_kembali ? tanggal_indonesia($item->tanggal_kembali, false) : ''); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>  
    <?php endif; ?>
    
</body>
</html><?php /**PATH F:\aset_ahg\resources\views/laporan_mobilisasi/laporan.blade.php ENDPATH**/ ?>