<div class="modal fade" id="modal-permintaan" tabindex="-1" role="dialog" aria-labelledby="modal-permintaan">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span
                        aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">Pilih permintaan</h4>
            </div>
            <div class="modal-body">
                <table class="table table-striped table-bordered table-permintaan">
                    <thead>
                        <th width="5%">No</th>
                        <th>Tanggal</th>
                        <th>Kode Permintaan</th>
                        <th>Kode Customer</th>
                        <th>Keluhan</th>
                        <th>Mekanik</th>
                        <th>Status</th>
                        <th><i class="fa fa-cog"></i></th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $permintaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td width="5%"><?php echo e($key+1); ?></td>
                                <td><?php echo e($item->tanggal); ?></td>
                                <td><?php echo e($item->kode_permintaan); ?></td>
                                <td><?php echo e($item->kode_kabin); ?></td>
                                <td><?php echo e($item->Keluhan); ?></td>
                                <td><?php echo e($item->nama_petugas); ?></td>
                                <td><?php echo e($item->status); ?></td>
                                <td>
                                    <a href="<?php echo e(route('service.create', $item->id)); ?>" class="btn btn-primary btn-xs btn-flat">
                                        <i class="fa fa-check-circle"></i>
                                        Pilih
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div><?php /**PATH F:\aset_ahg\resources\views/service/permintaan.blade.php ENDPATH**/ ?>