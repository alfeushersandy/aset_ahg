<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo e(url(auth()->user()->foto ?? '')); ?>" class="img-circle img-profil" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo e(auth()->user()->name); ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>
        
        <!-- /.search form -->
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">
            <li>
                <a href="<?php echo e(route('dashboard')); ?>">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
            </li>

            <?php if(auth()->user()->level == 1): ?>
            <li class="header">MASTER</li>
            <li>
                <a href="<?php echo e(route('departemen.index')); ?>">
                    <i class="fa fa-building"></i> <span>Departemen</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('kategori.index')); ?>">
                    <i class="fa fa-cube"></i> <span>Kategori</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('mekanik.index')); ?>">
                    <i class="fa fa-user-circle-o"></i> <span>Petugas</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('barang.index')); ?>">
                    <i class="fa fa-cubes"></i> <span>Barang</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('member.index')); ?>">
                    <i class="fa fa-id-card"></i> <span>Asset</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('lokasi.index')); ?>">
                    <i class="fa fa-map-marker"></i> <span>Lokasi</span>
                </a>
            </li>
            <li class="header">Perencanaan</li>
            <li>
                <a href="<?php echo e(route('perencanaan.index')); ?>">
                    <i class="fa fa-money"></i> <span>Perencanaan</span>
                </a>
            </li>
            <li class="header">Penerimaan Barang</li>
            <li>
                <a href="<?php echo e(route('penerimaan.index')); ?>">
                    <i class="fa fa-share"></i> <span>Penerimaan Barang</span>
                </a>
            </li>
            <li class="header">TRANSAKSI</li>
            <li>
                <a href="<?php echo e(route('permintaan.index')); ?>">
                    <i class="fa fa-wrench"></i> <span>Permintaan Service</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('mobilisasi.index')); ?>">
                    <i class="fa fa-truck"></i> <span>Mobilisasi / Mutasi Aset</span>
                </a>
            </li>
            
            <li class="header">REPORT</li>
            <li>
                <a href="<?php echo e(route('service.history')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Service</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('sparepart.index')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Sparepart</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('mobilisasi.report')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Mobilisasi</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('perencanaan.laporan')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Perencanaan</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('penerimaan.laporan')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Penerimaan Barang</span>
                </a>
            </li>
            <li class="header">SYSTEM</li>
            <li>
                <a href="<?php echo e(route('user.index')); ?>">
                    <i class="fa fa-users"></i> <span>User</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route("setting.index")); ?>">
                    <i class="fa fa-cogs"></i> <span>Pengaturan</span>
                </a>
            </li>
            <?php elseif(auth()->user()->level == 2): ?>
            <li class="header">MASTER</li>
            <li>
                <a href="<?php echo e(route('departemen.index')); ?>">
                    <i class="fa fa-building"></i> <span>Departemen</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('kategori.index')); ?>">
                    <i class="fa fa-cube"></i> <span>Kategori</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('mekanik.index')); ?>">
                    <i class="fa fa-wrench"></i> <span>Petugas</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('barang.index')); ?>">
                    <i class="fa fa-cubes"></i> <span>Barang</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('member.index')); ?>">
                    <i class="fa fa-id-card"></i> <span>Asset</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('lokasi.index')); ?>">
                    <i class="fa fa-map-marker"></i> <span>Lokasi</span>
                </a>
            </li>
            <li class="header">Perencanaan</li>
            <li>
                <a href="<?php echo e(route('perencanaan.index')); ?>">
                    <i class="fa fa-money"></i> <span>Perencanaan</span>
                </a>
            </li>
            <li class="header">Penerimaan Barang</li>
            <li>
                <a href="<?php echo e(route('penerimaan.index')); ?>">
                    <i class="fa fa-share"></i> <span>Penerimaan Barang</span>
                </a>
            </li>
            <li class="header">TRANSAKSI</li>
            <li>
                <a href="<?php echo e(route('permintaan.index')); ?>">
                    <i class="fa fa-truck"></i> <span>Permintaan Service</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('mobilisasi.index')); ?>">
                    <i class="fa fa-truck"></i> <span>Mobilisasi / Mutasi Aset</span>
                </a>
            </li>
            <li class="header">REPORT</li>
            <li>
                <a href="<?php echo e(route('service.history')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Service</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('sparepart.index')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Sparepart</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('mobilisasi.report')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Mobilisasi</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('perencanaan.laporan')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Perencanaan</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('penerimaan.laporan')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Penerimaan Barang</span>
                </a>
            </li>
            <?php elseif(auth()->user()->level == 3): ?>
            <li class="header">Perencanaan</li>
            <li>
                <a href="<?php echo e(route('perencanaan.index')); ?>">
                    <i class="fa fa-money"></i> <span>Perencanaan</span>
                </a>
            </li>
            <li class="header">Penerimaan Barang</li>
            <li>
                <a href="<?php echo e(route('penerimaan.index')); ?>">
                    <i class="fa fa-share"></i> <span>Penerimaan Barang</span>
                </a>
            </li>
            <li class="header">TRANSAKSI</li>
            <li>
                <a href="<?php echo e(route('permintaan.index')); ?>">
                    <i class="fa fa-wrench"></i> <span>Permintaan Service</span>
                </a>
            </li>
            <?php elseif(auth()->user()->level == 4): ?>
            <li>
                <a href="<?php echo e(route('barang.index')); ?>">
                    <i class="fa fa-cubes"></i> <span>Barang</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('service.index')); ?>">
                    <i class="fa fa-wrench"></i> <span>Permintaan Service</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('perencanaan.laporan')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Perencanaan</span>
                </a>
            </li>
            <li>
                <a href="<?php echo e(route('penerimaan.laporan')); ?>">
                    <i class="fa fa-file-pdf-o"></i> <span>Laporan Penerimaan Barang</span>
                </a>
            </li>
            <?php endif; ?>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside><?php /**PATH F:\aset_ahg\resources\views/layouts/sidebar.blade.php ENDPATH**/ ?>