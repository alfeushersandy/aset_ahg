

<?php $__env->startSection('title'); ?>
    Daftar Service Selesai
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('breadcrumb'); ?>
    <li class="active">Daftar Service Selesai</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(Auth::user()->level == 4): ?>
<ul class="nav nav-tabs">
    <li role="presentation" class="active"><a href="<?php echo e(route('service.index')); ?>">
        <span>Service On Progress</span>
    </a></li>
</ul>
<?php else: ?>
    <ul class="nav nav-tabs">
        <li role="presentation" > <a href="<?php echo e(route('permintaan.index')); ?>">
            <span>Permintaan Service</span>
        </a></li>
        <li role="presentation"><a href="<?php echo e(route('service.index')); ?>">
            <span>Service On Progress</span>
        </a></li>
        <li role="presentation" class="active"><a href="<?php echo e(route('service.selesai')); ?>">
            <span>Service Selesai</span>
        </a></li>
    </ul>
<?php endif; ?>
<div class="row">
    <div class="col-lg-12">
        <div class="box">
            <div class="box-body table-responsive">
                <table class="table table-stiped table-bordered table-selesai">
                    <thead>
                        <th width="5%">No</th>
                        <th>Tanggal</th>
                        <th>Kode Permintaan</th>
                        <th>Kode Kendaraan</th>
                        <th>Unit / Lokasi</th>
                        <th>User / Operator</th>
                        <th>Keluhan</th>
                        <th>Mekanik</th>
                        <th>Status</th>
                        <th>Waktu Selesai</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $permintaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td width="5%"><?php echo e($key+1); ?></td>
                                <td><?php echo e($item->tanggal); ?></td>
                                <td><?php echo e($item->kode_permintaan); ?></td>
                                <td><?php echo e($item->kode_kabin); ?></td>
                                <td><?php echo e($item->nama_lokasi); ?></td>
                                <td><?php echo e($item->user); ?></td>
                                <td><?php echo e($item->Keluhan); ?></td>
                                <td><?php echo e($item->nama_petugas); ?></td>
                                <td><?php echo e($item->status); ?></td>
                                <td><?php echo e($item->updated_at); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>

    let table
    $(function () {
        table = $('.table-selesai').DataTable();
    })
    // let table, table1;

    // $(function () {
    //     // table = $('.table-pembelian').DataTable({
    //     //     responsive: true,
    //     //     processing: true,
    //     //     serverSide: true,
    //     //     autoWidth: false,
    //     //     ajax: {
    //     //         url: '<?php echo e(route('service.data')); ?>',
    //     //     },
    //     //     columns: [
    //     //         {data: 'select_all', searchable: false, sortable: false},
    //     //         {data: 'DT_RowIndex', searchable: false, sortable: false},
    //     //         {data: 'tanggal'},
    //     //         {data: 'kode_permintaan'},
    //     //         {data: 'kode_kabin'},
    //     //         {data: 'user'},
    //     //         {data: 'Keluhan'},
    //     //         {data: 'nama'},
    //     //         {data: 'status'},
    //     //         {data: 'aksi', searchable: false, sortable: false},
    //     //     ]
    //     // });

    //     $('.table-supplier').DataTable();
    //     table1 = $('.table-detail').DataTable({
    //         processing: true,
    //         bSort: false,
    //         dom: 'Brt',
    //         columns: [
    //             {data: 'DT_RowIndex', searchable: false, sortable: false},
    //             {data: 'kode_produk'},
    //             {data: 'nama_produk'},
    //             {data: 'harga_beli'},
    //             {data: 'jumlah'},
    //             {data: 'subtotal'},
    //         ]
    //     })
    // });

    function addForm() {
        $('#modal-permintaan').modal('show');
    }

    function addFormsparepart() {
        $('#modal-sparepart').modal('show');
    }

    function showDetail(url) {
        $('#modal-detail').modal('show');

        table1.ajax.url(url);
        table1.ajax.reload();
    }

    function selesai(url) {
        $.get(url)
            .done((response) => {
                table.ajax.reload();
            })
            .fail((errors) => {
                alert('Tidak dapat meneruskan perintah');
                return;
            });
    }

    function deleteData(url) {
        if (confirm('Yakin ingin menghapus data terpilih?')) {
            $.post(url, {
                    '_token': $('[name=csrf-token]').attr('content'),
                    '_method': 'delete'
                })
                .done((response) => {
                    table.ajax.reload();
                })
                .fail((errors) => {
                    alert('Tidak dapat menghapus data');
                    return;
                });
        }
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\aset_ahg\resources\views/selesai/index.blade.php ENDPATH**/ ?>