<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>LAPORAN PERENCANAAN PDF</title>

    <style>
        table td {
            /* font-family: Arial, Helvetica, sans-serif; */
            font-size: 14px;
        }
        table.data td,
        table.data th {
            border: 1px solid #ccc;
            padding: 5px;
        }
        table.data {
            border-collapse: collapse;
        }
        .text-center {
            text-align: center;
        }
        .text-right {
            text-align: right;
        }
    </style>
</head>
<body>
    <table width="100%">
        <tr>
            <td rowspan="4" width="60%">
                <img src="<?php echo e(public_path($setting->path_logo)); ?>" alt="<?php echo e($setting->path_logo); ?>" width="120">
                <br>
                <?php echo e($setting->alamat); ?>

                <br>
            </td>
            <td width="15%">Tanggal Cetak</td>
            <td>: <?php echo e(tanggal_indonesia(date('Y-m-d'))); ?></td>
        </tr>
        <tr>
            <td>Cetak by</td>
            <td>: <?php echo e(Auth::user()->name ?? ''); ?></td>
        </tr>
    </table>
        <h1 class="text-center">Laporan Perencanaan Kendaraan</h1>
        <h2 class="text-center">Periode <?php echo e(date('d-m-Y', strtotime($tanggal_awal))); ?> - <?php echo e(date('d-m-Y',strtotime($tanggal_akhir))); ?></h2>
    <table class="data" width="100%">
        <thead>
            <tr>
                <th>No</th>
                <th>Kode Aset</th>
                <th>Total Item</th>
                <th>Total Harga</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $permintaan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($key+1); ?></td>
                    <td class="text-center"><?php echo e($item->kode_kabin); ?></td>
                    <td class="text-center"><?php echo e($item->sum_item); ?></td>
                    <td class="text-right"><?php echo e(format_uang($item->sum_harga)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr>
                <td colspan="3" class="text-right"><b>Total biaya</b></td>
                <td class="text-right"><b><?php echo e(format_uang($sum)); ?></b></td>
            </tr>
        </tfoot>
    </table>
</body>
</html><?php /**PATH F:\aset_ahg\resources\views/laporan_perencanaan_all/rekap.blade.php ENDPATH**/ ?>