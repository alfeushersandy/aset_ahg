

<?php $__env->startSection('title'); ?>
    Daftar Barang Keluar
<?php $__env->stopSection(); ?>

<?php $__env->startSection('breadcrumb'); ?>
    <?php echo \Illuminate\View\Factory::parentPlaceholder('breadcrumb'); ?>
    <li class="active">Daftar Barang Keluar</li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="box">
            <div class="box-header with-border">
                <button onclick="addForm('<?php echo e(route('gudang.create')); ?>')" class="btn btn-success btn-xs btn-flat"><i class="fa fa-plus-circle"></i>Tambah Permintaan Barang Keluar</button>
            </div>
            <div class="box-body table-responsive">
                <table class="table table-stiped table-bordered table-barang-keluar">
                    <thead>
                        <th width="5%">
                            <input type="checkbox" name="select_all" id="select_all">
                        </th>
                        <th width="5%">No</th>
                        <th>Tanggal</th>
                        <th>Pemohon</th>
                        <th>Keperluan</th>
                        <th>Detail Keperluan</th>
                        <th>Keterangan</th>
                        <th>Status</th>
                        <th width="15%"><i class="fa fa-cog"></i></th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $barang_keluar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop); ?></td>
                                <td><?php echo e($item->tanggal); ?></td>
                                <td><?php echo e($item->pemohon_id); ?></td>
                                <td><?php echo e($item->keperluan); ?></td>
                                <td><?php echo e($item->kode_keperluan); ?></td>
                                <td><?php echo e($item->keterangan); ?></td>
                                <td><?php echo e($item->status); ?></td>
                                <td>
                                    <a href="">edit</a>
                                    <a href="">delete</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php if ($__env->exists('barangkeluar.form')) echo $__env->make('barangkeluar.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    let table;

    $(function () {
        table = $('.table-barang-keluar').DataTable()


        $('#keperluan').on('change', function(){
            if($(this).val() == 'service'){
                $('div[name=input_keperluan]').empty();
                $('#label_keperluan').text('kode_service');
                $.ajax({
                    url: 'kodeservice',
                    type: 'GET',
                    dataType: 'json',
                    success: function(data)
                    {
                        $('div[name=input_keperluan]').append("<select name='kode_keperluan' id='kode_keperluan' class='form-control' required></select>");
                        $.each(data, function(key, kode){
                            $('select[name="kode_keperluan"]').append('<option value="'+kode.kode_permintaan+'">' + kode.kode_permintaan + '</option>');
                        });
                    }
                })
            }else if($(this).val() == 'lain lain'){
                $('div[name="input_keperluan"]').empty();
                $('#label_keperluan').text('Catatan Keperluan');
                $('div[name="input_keperluan"]').append('<input type="text" name="kode_keperluan" id="kode_keperluan" class="form-control">');
            }else{
                $('#label_keperluan').empty();
                $('div[name="input_keperluan"]').empty();
            }
        })
    });

    function addForm(url) {
        $('#modal-form').modal('show');
        $('#label_keperluan').empty();
        $('div[name="input_keperluan"]').empty();

        $('#modal-form form')[0].reset();
        $('#modal-form form').attr('action', url);
        $('#modal-form [name=_method]').val('post');
    }


    function showDetail(url) {
        $('#modal-detail').modal('show');

        table1.ajax.url(url);
        table1.ajax.reload();
    }

    function deleteData(url) {
        if (confirm('Yakin ingin menghapus data terpilih?')) {
            $.post(url, {
                    '_token': $('[name=csrf-token]').attr('content'),
                    '_method': 'delete'
                })
                .done((response) => {
                    table.ajax.reload();
                })
                .fail((errors) => {
                    alert('Tidak dapat menghapus data');
                    return;
                });
        }
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\aset_ahg\resources\views/barangkeluar/index.blade.php ENDPATH**/ ?>