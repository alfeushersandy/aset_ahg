<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>LAPORAN MOBILISASI PDF</title>

    <style>
        table td {
            /* font-family: Arial, Helvetica, sans-serif; */
            font-size: 14px;
        }
        table.data td,
        table.data th {
            border: 1px solid #ccc;
            padding: 5px;
        }
        table.data {
            border-collapse: collapse;
        }
        .text-center {
            text-align: center;
        }
        .text-right {
            text-align: right;
        }
    </style>
</head>
<body>
    <table width="100%">
        <tr>
            <td rowspan="4" width="60%">
                <img src="<?php echo e(public_path($setting->path_logo)); ?>" alt="<?php echo e($setting->path_logo); ?>" width="120">
                <br>
                <?php echo e($setting->alamat); ?>

                <br>
            </td>
            <td width="40%">Tanggal Cetak : <?php echo e(tanggal_indonesia(date('Y-m-d'))); ?></td>
        </tr>
    </table>
        <h3 class="text-center">Laporan Aset Kategori <?php echo e($kategori->nama_kategori); ?></h3>
        
    <table class="data" width="100%" style="margin-top: 15px">
        <thead>
            <tr>
                <th width="5%">No</th>
                <th>Kode</th>
                <th>Kategori</th>
                <th>Kode Asset</th>
                <th>Identitas Aset</th>
                <th>User / Operator</th>
            </tr>
        </thead>
        <?php
            $no = 1;
        ?>
        <tbody>
            <?php $__currentLoopData = $member; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($no++); ?></td>
                    <td><?php echo e($item->kode_member); ?></td>
                    <td><?php echo e($item->kategori->nama_kategori); ?></td>
                    <td><?php echo e($item->kode_kabin); ?></td>
                    <td><?php echo e($item->nopol); ?></td>
                    <td><?php echo e($item->user); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>    
</body>
</html><?php /**PATH F:\aset_ahg\resources\views/member/laporan_kategori.blade.php ENDPATH**/ ?>